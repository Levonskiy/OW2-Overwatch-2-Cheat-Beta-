## Fortnite cheat updated
Fortnite internal cheat.


# updated 
 - supports x64 / x86
 - widows 11 support
 - new injection methods 

# updated 18/09/2022
- changed driver issues 
  - fixed bsod issues when anticheat loads 
  - fixed hosting server not streaming bytes
  - bypass guarded regions
  - dll size can now be higher than 1mb 


# changes
 - 20/07/2022
   - WindowsHook -> added ( how to use ? | enter your dll filepath + the name of the dll | then simply write what you want the output name to be ( example "cheat" )
     what does it do ? | it converts your dll into bytes allowing the injector to read the dll bytes and inject them into your targeted game.
   
# active updates + changes to keep this undetected and safe to use !
## - Make Sure you read how to use and the rest of the information about this.  
be kind and leave a star

# how to use ?
- run cheat.exe (auto kdmap cheat driver)
be sure u turned off faceit anti-cheat. (Run cmd and enter "sc stop faceit")
## how status works 🔵 = undetected | 🔴 = detected
## working anti-cheats that injector supports
* Easy Anti Cheat🔵
* BattlEye Anti Cheat🔵

# windows versions from 1909 / 20h2

# little insight on the release
i thought not many people release working injectors these days that can actually inject past EAC and other anti-cheats i want to be able to provide a working injector for upcoming cheat developers or just individual people who dont understand code and want to cheat on a anti-cheat protected game.

## why not release injector source and driver source?
because i dont agree with the fact of many people skidding on developers work in this category ( fair enough for cheats ) but injectors and drivers are more important to keep private although i will sell this source code for a reasonable price.


